--
-- PostgreSQL database dump
--

\restrict jO7paEpIixgldrTElQjr6eMdDpnbkpvCkpI2c7ECAprTejb2f89u2LAIf0Z3r2Q

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attendance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_name text,
    branch_id uuid,
    date text NOT NULL,
    status text DEFAULT 'libur'::text NOT NULL,
    notes text,
    created_at text NOT NULL,
    created_by text,
    created_by_name text
);


ALTER TABLE public.attendance OWNER TO postgres;

--
-- Name: banks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bank_name text NOT NULL,
    balance double precision DEFAULT 0 NOT NULL,
    branch_id uuid,
    created_at text,
    updated_at text
);


ALTER TABLE public.banks OWNER TO postgres;

--
-- Name: branch_deposits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.branch_deposits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    branch_id uuid NOT NULL,
    total_setor double precision DEFAULT 0 NOT NULL,
    sisa_setor double precision DEFAULT 0 NOT NULL,
    berhasil_disetor double precision DEFAULT 0 NOT NULL,
    destination text,
    description text,
    date text NOT NULL,
    created_by text,
    created_by_name text,
    status text DEFAULT 'pending'::text,
    received_by text,
    received_by_name text,
    received_at text,
    atm_name text,
    completed_by text,
    completed_by_name text,
    completed_at text,
    edit_history jsonb
);


ALTER TABLE public.branch_deposits OWNER TO postgres;

--
-- Name: branches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.branches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    capital double precision DEFAULT 0,
    physical_capital double precision DEFAULT 0,
    shifted_capital double precision DEFAULT 0,
    total_setor double precision,
    created_at text NOT NULL
);


ALTER TABLE public.branches OWNER TO postgres;

--
-- Name: customer_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    customer_id uuid NOT NULL,
    amount double precision NOT NULL,
    description text,
    type text NOT NULL,
    date text NOT NULL,
    created_by text
);


ALTER TABLE public.customer_transactions OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    person_name text NOT NULL,
    branch_id uuid,
    owner_type text DEFAULT 'nasabah'::text,
    user_id uuid,
    created_at text NOT NULL
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: salary_slips; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.salary_slips (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_name text,
    role text,
    branch_id uuid,
    branch_name text,
    month integer,
    year integer,
    base_salary double precision DEFAULT 0,
    bonus double precision DEFAULT 0,
    deductions double precision DEFAULT 0,
    net_salary double precision DEFAULT 0,
    daily_rate double precision DEFAULT 0,
    days_off integer DEFAULT 0,
    debt_payment double precision DEFAULT 0,
    saving_deposit double precision DEFAULT 0,
    saving_withdraw double precision DEFAULT 0,
    status text DEFAULT 'pending'::text,
    created_at text,
    paid_at text,
    created_by text,
    created_by_name text
);


ALTER TABLE public.salary_slips OWNER TO postgres;

--
-- Name: saving_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.saving_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    saving_id uuid NOT NULL,
    amount double precision NOT NULL,
    description text,
    type text NOT NULL,
    date text NOT NULL,
    created_by text,
    created_by_name text
);


ALTER TABLE public.saving_transactions OWNER TO postgres;

--
-- Name: savings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.savings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    person_name text NOT NULL,
    phone text,
    branch_id uuid,
    owner_type text DEFAULT 'nasabah'::text,
    user_id uuid,
    created_at text NOT NULL
);


ALTER TABLE public.savings OWNER TO postgres;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    id text DEFAULT 'general'::text NOT NULL,
    fixed_balance double precision DEFAULT 0,
    announcement text DEFAULT ''::text,
    updated_at text
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    email text,
    name text NOT NULL,
    role text DEFAULT 'karyawan'::text NOT NULL,
    branch_id uuid,
    phone text,
    created_at text NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: voucher_recaps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.voucher_recaps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    date text NOT NULL,
    admin_siang double precision DEFAULT 0,
    admin_malam double precision DEFAULT 0,
    voucher_siang double precision DEFAULT 0,
    voucher_malam double precision DEFAULT 0,
    expense_amount double precision DEFAULT 0,
    expense_description text,
    total double precision DEFAULT 0,
    description text,
    branch_id uuid,
    status text DEFAULT 'reported'::text,
    created_at text,
    created_by text,
    created_by_name text
);


ALTER TABLE public.voucher_recaps OWNER TO postgres;

--
-- Data for Name: attendance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendance (id, user_id, user_name, branch_id, date, status, notes, created_at, created_by, created_by_name) FROM stdin;
f3cb7ced-910e-47ba-812a-2ee4838da8af	988d51cf-5832-4a53-9224-fa7fb8d618f1	Tedi	57c7bf62-4c12-4df8-9098-14032ce58099	2026-07-16	libur	\N	2026-07-16T14:00:08.327Z	e97259d0-627f-4fbc-8354-ce1c09c7fffc	Bos
812aa32c-57b8-4057-8036-e8b73e952ca0	988d51cf-5832-4a53-9224-fa7fb8d618f1	Tedi	57c7bf62-4c12-4df8-9098-14032ce58099	2026-07-15	libur	\N	2026-07-16T14:00:11.412Z	e97259d0-627f-4fbc-8354-ce1c09c7fffc	Bos
\.


--
-- Data for Name: banks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banks (id, bank_name, balance, branch_id, created_at, updated_at) FROM stdin;
78afa4b6-a85f-442e-bcc9-1a58194fac53	Bca	200000	57c7bf62-4c12-4df8-9098-14032ce58099	2026-07-16T14:04:43.879Z	2026-07-16T14:04:43.879Z
fcf170e5-7cc2-4903-b3c4-40c7257d3761	Nobu	500000	57c7bf62-4c12-4df8-9098-14032ce58099	2026-07-16T14:04:50.763Z	2026-07-16T14:04:50.763Z
cfb414ec-1a44-451b-a7b8-24b530f6d4c4	Bca	300000	827f49bc-ab5c-4209-b7f7-c1469cef7f5b	2026-07-16T15:49:18.733Z	2026-07-16T15:49:18.733Z
\.


--
-- Data for Name: branch_deposits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.branch_deposits (id, branch_id, total_setor, sisa_setor, berhasil_disetor, destination, description, date, created_by, created_by_name, status, received_by, received_by_name, received_at, atm_name, completed_by, completed_by_name, completed_at, edit_history) FROM stdin;
541d3830-1168-4e38-b8cc-744cfa7aad2d	827f49bc-ab5c-4209-b7f7-c1469cef7f5b	500000	400000	100000	Mandor	Pahi	2026-07-16T15:51:32.132Z	044f4a20-73b6-4211-8104-a903134ba067	Daniramdani	verified	988d51cf-5832-4a53-9224-fa7fb8d618f1	Tedi	2026-07-16T15:51:57.563Z	BCA	988d51cf-5832-4a53-9224-fa7fb8d618f1	Tedi	2026-07-16T15:52:24.310Z	\N
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.branches (id, name, capital, physical_capital, shifted_capital, total_setor, created_at) FROM stdin;
57c7bf62-4c12-4df8-9098-14032ce58099	ALFATH 1	15000000	500000	0	\N	2026-07-16T13:43:41.734Z
827f49bc-ab5c-4209-b7f7-c1469cef7f5b	ALFATH 2	3000000	500000	0	\N	2026-07-16T13:47:41.905Z
\.


--
-- Data for Name: customer_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_transactions (id, customer_id, amount, description, type, date, created_by) FROM stdin;
6f36b595-6313-4480-bf04-36a1273b9de0	0b155650-60c4-490c-a9bb-f7a85973ae71	500000	Dana	add	2026-07-16T17:37:36.421Z	988d51cf-5832-4a53-9224-fa7fb8d618f1
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, person_name, branch_id, owner_type, user_id, created_at) FROM stdin;
0b155650-60c4-490c-a9bb-f7a85973ae71	Jamal	827f49bc-ab5c-4209-b7f7-c1469cef7f5b	nasabah	\N	2026-07-16T17:37:26.407Z
\.


--
-- Data for Name: salary_slips; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.salary_slips (id, user_id, user_name, role, branch_id, branch_name, month, year, base_salary, bonus, deductions, net_salary, daily_rate, days_off, debt_payment, saving_deposit, saving_withdraw, status, created_at, paid_at, created_by, created_by_name) FROM stdin;
20db08bc-393d-482e-a5ff-8b65319e049e	988d51cf-5832-4a53-9224-fa7fb8d618f1	Tedi	karyawan	57c7bf62-4c12-4df8-9098-14032ce58099	ALFATH 1	7	2026	4650000	0	300000	4350000	150000	2	0	0	0	pending	2026-07-16T14:01:03.898Z	\N	e97259d0-627f-4fbc-8354-ce1c09c7fffc	Bos
\.


--
-- Data for Name: saving_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.saving_transactions (id, saving_id, amount, description, type, date, created_by, created_by_name) FROM stdin;
60c56048-6413-406a-b6bb-afb9fbfb7669	db46929a-1c4c-4f2c-8d5e-877084a332b1	500000	Nabubg	deposit	2026-07-16T14:05:32.579Z	988d51cf-5832-4a53-9224-fa7fb8d618f1	Tedi
f033ea84-b1a7-4d17-a928-d5b1258aa371	db46929a-1c4c-4f2c-8d5e-877084a332b1	600000	Nabung	deposit	2026-07-16T14:05:45.353Z	988d51cf-5832-4a53-9224-fa7fb8d618f1	Tedi
0eb2e7bf-7313-4cf3-98f3-00218b0a4cb8	85c2b5a2-3696-4892-90cb-3813c4eec5c6	300000	F	deposit	2026-07-16T17:38:10.248Z	044f4a20-73b6-4211-8104-a903134ba067	Daniramdani
\.


--
-- Data for Name: savings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.savings (id, person_name, phone, branch_id, owner_type, user_id, created_at) FROM stdin;
db46929a-1c4c-4f2c-8d5e-877084a332b1	Nina	08522235338	57c7bf62-4c12-4df8-9098-14032ce58099	nasabah	\N	2026-07-16T14:05:19.932Z
85c2b5a2-3696-4892-90cb-3813c4eec5c6	Oko	08523448454	827f49bc-ab5c-4209-b7f7-c1469cef7f5b	nasabah	\N	2026-07-16T17:38:03.349Z
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (id, fixed_balance, announcement, updated_at) FROM stdin;
general	0		2026-07-16T13:11:15.002Z
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password_hash, email, name, role, branch_id, phone, created_at) FROM stdin;
e97259d0-627f-4fbc-8354-ce1c09c7fffc	admin	b01f3e2c59fa3e26d3e64731a805156a:ff40a09fa6da6ddce8204f32fb145ee5a3aad1c867b6e8311065d737880ec5e709dd6c818ce6a3cb3164d8dae7ccc5c4f24cf6edc048765d0f7b7a2bd7b95474	alfathpulsa27@gmail.com	Bos	bos	\N	\N	2026-07-16T13:11:14.993Z
d10d782a-e56e-4e32-93b0-514fea68d8be	alfath2	5ccb0c94a20bc8dfdd23364fc5c29adc:1b2857ca0f6876702ef21be256eab06405ffe99378cd6c509f072f40c2c6b3c2201f2abf7571d46d1a4a03b9402cafe767e75019fd26513b28d7e47ca7e31267	\N	Ayi	karyawan	827f49bc-ab5c-4209-b7f7-c1469cef7f5b	\N	2026-07-16T13:48:10.991Z
988d51cf-5832-4a53-9224-fa7fb8d618f1	tedi	5a872f5f0e9964b58cc6d4f3844d175d:75332670bcb566b59cd6335547d6c1a1ee2814159fe964bf8bf3facc07268d8becd1235e07c8b89dc4f22078363976873cbad79b3f121efe71f741b913fcfed4	\N	Tedi	mandor	\N	\N	2026-07-16T13:44:17.339Z
044f4a20-73b6-4211-8104-a903134ba067	dani	36682c112f58572e09001fc4739f2d60:58333b62df27e8e1055f66bd86170d2c58f0aaefe036a6b621fbebd2880abf9969cd84fa3e2d90d469ce58264a73717a4d0ff7197f57e665c2188e9b4d49e8cc	\N	Daniramdani	karyawan	827f49bc-ab5c-4209-b7f7-c1469cef7f5b	\N	2026-07-16T15:45:01.737Z
\.


--
-- Data for Name: voucher_recaps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.voucher_recaps (id, date, admin_siang, admin_malam, voucher_siang, voucher_malam, expense_amount, expense_description, total, description, branch_id, status, created_at, created_by, created_by_name) FROM stdin;
d510b35a-9a7a-4778-a43f-40849b9d609e	2026-07-16	50000	30000	20000	20000	0		120000		57c7bf62-4c12-4df8-9098-14032ce58099	draft	2026-07-16T14:07:30.471Z	988d51cf-5832-4a53-9224-fa7fb8d618f1	Tedi
e8fb2b68-d44f-444e-be64-bd81fd8ff8f8	2026-07-16	300000	200000	700000	600000	0		1800000		827f49bc-ab5c-4209-b7f7-c1469cef7f5b	draft	2026-07-16T15:45:32.485Z	044f4a20-73b6-4211-8104-a903134ba067	Daniramdani
\.


--
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (id);


--
-- Name: banks banks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banks
    ADD CONSTRAINT banks_pkey PRIMARY KEY (id);


--
-- Name: branch_deposits branch_deposits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.branch_deposits
    ADD CONSTRAINT branch_deposits_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: customer_transactions customer_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_transactions
    ADD CONSTRAINT customer_transactions_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: salary_slips salary_slips_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_slips
    ADD CONSTRAINT salary_slips_pkey PRIMARY KEY (id);


--
-- Name: saving_transactions saving_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saving_transactions
    ADD CONSTRAINT saving_transactions_pkey PRIMARY KEY (id);


--
-- Name: savings savings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.savings
    ADD CONSTRAINT savings_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: voucher_recaps voucher_recaps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voucher_recaps
    ADD CONSTRAINT voucher_recaps_pkey PRIMARY KEY (id);


--
-- Name: attendance_branch_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendance_branch_id_idx ON public.attendance USING btree (branch_id);


--
-- Name: attendance_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendance_date_idx ON public.attendance USING btree (date);


--
-- Name: attendance_user_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendance_user_date_idx ON public.attendance USING btree (user_id, date);


--
-- Name: attendance_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendance_user_id_idx ON public.attendance USING btree (user_id);


--
-- Name: branch_deposits_branch_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX branch_deposits_branch_id_idx ON public.branch_deposits USING btree (branch_id);


--
-- Name: branch_deposits_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX branch_deposits_date_idx ON public.branch_deposits USING btree (date);


--
-- Name: customer_transactions_customer_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customer_transactions_customer_id_idx ON public.customer_transactions USING btree (customer_id);


--
-- Name: customers_branch_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_branch_id_idx ON public.customers USING btree (branch_id);


--
-- Name: customers_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_user_id_idx ON public.customers USING btree (user_id);


--
-- Name: salary_slips_branch_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX salary_slips_branch_id_idx ON public.salary_slips USING btree (branch_id);


--
-- Name: salary_slips_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX salary_slips_user_id_idx ON public.salary_slips USING btree (user_id);


--
-- Name: salary_slips_year_month_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX salary_slips_year_month_idx ON public.salary_slips USING btree (year, month);


--
-- Name: saving_transactions_saving_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX saving_transactions_saving_id_idx ON public.saving_transactions USING btree (saving_id);


--
-- Name: savings_branch_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX savings_branch_id_idx ON public.savings USING btree (branch_id);


--
-- Name: savings_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX savings_user_id_idx ON public.savings USING btree (user_id);


--
-- Name: voucher_recaps_branch_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX voucher_recaps_branch_id_idx ON public.voucher_recaps USING btree (branch_id);


--
-- Name: voucher_recaps_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX voucher_recaps_date_idx ON public.voucher_recaps USING btree (date);


--
-- PostgreSQL database dump complete
--

\unrestrict jO7paEpIixgldrTElQjr6eMdDpnbkpvCkpI2c7ECAprTejb2f89u2LAIf0Z3r2Q

